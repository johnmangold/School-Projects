This program uses a recursive DFS algorithm to solve the missionaries and cannibals problem.

Authors: John Mangold, Murray LaHood-Burns

Usage: From the CLISP interpreter:  this will load the program which will load all other needed files.
		(load 'missionaries_001)
		
	   To run the simulation:
		(m-c m c)
		
			m - number of missionaries to start
			c - number of cannibals to start